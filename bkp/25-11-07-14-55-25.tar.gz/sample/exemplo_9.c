boolean ativo;
ativo = true;

if (ativo) {
    // faz algo
}
