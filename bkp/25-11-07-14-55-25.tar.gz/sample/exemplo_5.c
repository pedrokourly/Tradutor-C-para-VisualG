int main() {
    int a;
    b = a + 5;  // Erro: 'b' não foi declarado
    return b;
}
