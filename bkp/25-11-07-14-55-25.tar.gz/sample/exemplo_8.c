string nome;
nome = "Getulio";

char letra;
letra = 'G';

boolean ativo;
ativo = true;
