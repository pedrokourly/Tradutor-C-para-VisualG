int x;
int x;  /* Erro: 'x' já foi declarado */

int main() {
    return x;
}
