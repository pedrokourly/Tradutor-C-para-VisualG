int main() {
    int x = 10; /* gramatica nao aceita atribuicao na declaracao.... */
    return x;
}