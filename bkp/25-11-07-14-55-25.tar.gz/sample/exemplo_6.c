int main() {
    int resultado;
    return resultado;  // Erro: 'resultado' não foi inicializado
}
