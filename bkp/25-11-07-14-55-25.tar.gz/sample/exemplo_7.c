int x;
float y;
double z;
char letra;

int main() {
    x = 10;
    y = 3.14;
    z = y + x;
    letra = 'A';

    return x;
}
