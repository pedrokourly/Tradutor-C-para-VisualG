int x;
int y;

int main() {
    int z;
    z = x + y;

    if ( x > 0 ) {
        z = 0;
    }
    return z;
}
